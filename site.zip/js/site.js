// Progressive enhancements only. All primary content and navigation are static HTML.
(() => {
  const video = document.querySelector('#studio-video');
  const replay = document.querySelector('#replay-video');
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (video && replay) {
    const stage = video.closest('.logo-stage');
    const state = document.querySelector('#video-state');
    let failed = false;
    const fallback = () => {
      video.pause();
      stage.classList.remove('is-playing', 'has-ended');
      state.textContent = motion.matches ? 'Static studio logo. Reduced motion is enabled.' : 'Static studio logo.';
    };
    const play = async () => {
      if (motion.matches || failed) return;
      video.muted = true;
      video.defaultMuted = true;
      video.loop = false;
      if (!video.getAttribute('src')) video.src = video.dataset.src;
      try {
        video.currentTime = 0;
        await video.play();
      } catch (_) { fallback(); }
    };
    video.addEventListener('playing', () => {
      stage.classList.add('is-playing');
      stage.classList.remove('has-ended');
      state.textContent = 'Playing muted studio logo animation.';
    });
    video.addEventListener('ended', () => {
      stage.classList.remove('is-playing');
      stage.classList.add('has-ended');
      state.textContent = 'Studio logo animation finished.';
    });
    video.addEventListener('error', () => {
      failed = true; fallback(); replay.hidden = true;
    });
    replay.addEventListener('click', play);
    motion.addEventListener('change', () => {
      if (motion.matches) {
        fallback(); video.removeAttribute('autoplay'); video.removeAttribute('src'); video.load(); replay.hidden = true;
      } else { replay.hidden = failed; /* Motion preference changes do not trigger autoplay. */ }
    });
    if (!motion.matches) {
      replay.hidden = false;
      // Let the first frame of the page render before requesting the video.
      requestAnimationFrame(() => requestAnimationFrame(play));
    } else {
      video.removeAttribute('autoplay');
      fallback();
    }
  }

  const filters = document.querySelector('.filters');
  if (filters) {
    filters.hidden = false;
    const cards = [...document.querySelectorAll('[data-category]')];
    filters.addEventListener('click', event => {
      const button = event.target.closest('[data-filter]');
      if (!button) return;
      filters.querySelectorAll('button').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
      cards.forEach(card => { card.hidden = button.dataset.filter !== 'all' && card.dataset.category !== button.dataset.filter; });
      document.querySelector('#filter-status').textContent = `${cards.filter(card => !card.hidden).length} projects shown.`;
    });
  }

  const previewGrid = document.querySelector('.preview-grid');
  if (previewGrid) {
    // A visitor can switch clips without leaving several videos playing at once.
    previewGrid.addEventListener('play', event => {
      previewGrid.querySelectorAll('video').forEach(other => {
        if (other !== event.target) other.pause();
      });
    }, true);
  }

  const dialog = document.querySelector('.image-dialog');
  let lastTrigger;
  if (dialog && typeof dialog.showModal === 'function') {
    document.querySelectorAll('[data-lightbox]').forEach(anchor => {
      anchor.addEventListener('click', event => {
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        lastTrigger = anchor;
        const image = dialog.querySelector('img');
        image.src = anchor.href;
        image.alt = anchor.querySelector('img').alt;
        dialog.querySelector('p').textContent = anchor.dataset.caption;
        dialog.showModal();
      });
    });
    dialog.addEventListener('click', event => {
      if (event.target === dialog) {
        const rect = dialog.getBoundingClientRect();
        if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
      }
    });
    dialog.addEventListener('close', () => lastTrigger?.focus());
  }
})();
