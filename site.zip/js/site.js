// Progressive enhancements only. All primary content and navigation are static HTML.
(() => {
  const video = document.querySelector('#studio-video');
  const toggle = document.querySelector('#toggle-logo-animation');
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  if (video && toggle) {
    const stage = video.closest('.logo-stage');
    const state = document.querySelector('#video-state');
    let failed = false;
    const button = (label, hidden = false) => {
      toggle.textContent = label;
      toggle.setAttribute('aria-label', label.replace(' animation', '') + ' studio logo animation');
      toggle.hidden = hidden;
    };
    // Start through play(), rather than the autoplay attribute that can make
    // iOS display a native start-playback overlay when autoplay is blocked.
    video.removeAttribute('autoplay');
    video.removeAttribute('controls');
    video.controls = false;
    video.playsInline = true;
    video.muted = true;
    video.defaultMuted = true;
    video.loop = true;
    const fallback = () => {
      video.pause();
      stage.classList.remove('is-playing');
      state.textContent = motion.matches ? 'Static studio logo. Reduced motion is enabled.' : 'Static studio logo.';
      button('Play animation', motion.matches || failed);
    };
    const play = async () => {
      if (motion.matches || failed) return;
      if (!video.getAttribute('src')) video.src = video.dataset.src;
      try {
        await video.play();
        if (motion.matches || failed) fallback();
      } catch (_) { fallback(); }
    };
    video.addEventListener('playing', () => {
      if (motion.matches || failed) { fallback(); return; }
      stage.classList.add('is-playing');
      state.textContent = 'Playing muted, looping studio logo animation.';
      button('Pause animation');
    });
    video.addEventListener('error', () => {
      failed = true;
      fallback();
    });
    toggle.addEventListener('click', () => {
      if (video.paused) play();
      else {
        video.pause();
        state.textContent = 'Studio logo animation paused.';
        button('Resume animation');
      }
    });
    motion.addEventListener('change', () => {
      if (motion.matches) {
        fallback();
        video.removeAttribute('src');
        video.load();
      } else {
        button('Play animation', failed);
        // A preference change alone does not start motion unexpectedly.
      }
    });
    if (!motion.matches) {
      requestAnimationFrame(() => requestAnimationFrame(play));
    } else fallback();
  }

  const filters = document.querySelector('.filters');
  if (filters) {
    filters.hidden = false;
    const cards = [...document.querySelectorAll('[data-category]')];
    filters.addEventListener('click', event => {
      const button = event.target.closest('[data-filter]');
      if (!button) return;
      filters.querySelectorAll('button').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
      cards.forEach(card => { card.hidden = button.dataset.filter !== 'all' && card.dataset.category !== button.dataset.filter; });
      document.querySelector('#filter-status').textContent = `${cards.filter(card => !card.hidden).length} projects shown.`;
    });
  }

  const previewGrid = document.querySelector('.preview-grid');
  if (previewGrid) {
    // A visitor can switch clips without leaving several videos playing at once.
    previewGrid.addEventListener('play', event => {
      previewGrid.querySelectorAll('video').forEach(other => {
        if (other !== event.target) other.pause();
      });
    }, true);
  }

  const dialog = document.querySelector('.image-dialog');
  let lastTrigger;
  if (dialog && typeof dialog.showModal === 'function') {
    document.querySelectorAll('[data-lightbox]').forEach(anchor => {
      anchor.addEventListener('click', event => {
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        lastTrigger = anchor;
        const image = dialog.querySelector('img');
        image.src = anchor.href;
        image.alt = anchor.querySelector('img').alt;
        dialog.querySelector('p').textContent = anchor.dataset.caption;
        dialog.showModal();
      });
    });
    dialog.addEventListener('click', event => {
      if (event.target === dialog) {
        const rect = dialog.getBoundingClientRect();
        if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
      }
    });
    dialog.addEventListener('close', () => lastTrigger?.focus());
  }
})();
