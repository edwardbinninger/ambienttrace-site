StoreSculpt website media

editor.png is an unaltered window capture of the actual running StoreSculpt Mac development build on November 6, 2026. It shows the Video Editor rendering a SpriteTailor preview, not a fictional interface. Native dimensions: 2300 × 1760.

The same capture is used on homepage/catalog cards, the hero, and the reusable enlarged screenshot gallery. Replace the registry paths, alt text, and dimensions in src/data/projects.json to update media later. StoreSculpt is Coming Soon — Mac; no price, release date, or App Store URL is assigned.
