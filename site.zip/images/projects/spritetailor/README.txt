Owner-supplied macOS screenshots added November 4, 2026.
Originals remain unchanged in MacApp-pngtrimmer/Screenshots/macOS/AppStore-2880x1800/.
Lossless WebP copies retain the full 2880 x 1800 pixels and 16:10 proportions:
01_MainScreen.png -> main-screen.webp (featured image and first gallery item)
02_AutomaticSlice.png -> automatic-slice.webp
03_PolygonTool.png -> polygon-tool.webp
04_TrimResize.png -> trim-resize.webp
05_AtlasPacker.png -> atlas-packer.webp
Captions and alt text are maintained in src/data/projects.json.
