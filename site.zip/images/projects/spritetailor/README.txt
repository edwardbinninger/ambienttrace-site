SpriteTailor Mac screenshots replaced November 5, 2026.
Sources: MacApp-pngtrimmer/Submission_Resources/Mac version 1.1/Screenshots/MyApp/Screenshots/Mac_2880_2880x1800/
Originals remain unchanged. Lossless WebP copies preserve all RGB pixels at 2880 x 1800 (16:10).
01 MainScreen -> v1-1-main-screen.webp (owner-selected featured image)
02 SpriteSlicing -> v1-1-sprite-slicing.webp
03 PolygonSlicing -> v1-1-polygon-slicing.webp
04 BatchTrimeResize -> v1-1-trim-resize.webp
05 EdgeBlending -> v1-1-edge-blending.webp
06 FileRename -> v1-1-batch-renamer.webp
07 TextureAtls -> v1-1-atlas-packer.webp
Captions and alt text are maintained in src/data/projects.json.
The previous five-image set was replaced; its source copies remain recoverable in Git history.
