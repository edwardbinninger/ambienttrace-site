Boomyard media supplied by Ambient Trace Studio.

Seven portrait images, including the actual iPhone main menu and promotional screenshots/composite artwork. JPEG web copies preserve the supplied image dimensions and composition; no cropping or generated imagery. The main-menu capture is used for the project feature.

Three full-length H.264/AAC preview clips and their extracted poster frames are under /media/projects/boomyard/. Previews play only when selected.
