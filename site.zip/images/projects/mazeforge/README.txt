Place owner-approved mazeforge artwork and screenshots here.
Register files, original width/height, alt text, and truthful captions in src/data/projects.json.
Null image sources render clearly labeled placeholders. Portrait images are displayed uncropped.
