# States & Capitals Quiz media

Owner-supplied promotional screenshots from the rebuilt iPhone app. Full portrait artwork is preserved; these JPEGs are optimized website copies. The main feature is 01-know-america.jpg. The gallery order and descriptive text live in src/data/projects.json, so media can be replaced centrally without changing the layout.

Preview posters are actual frames from the two supplied videos. No gameplay or results imagery has been fabricated.
